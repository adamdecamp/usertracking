INFORMATION SYSTEM USER TRACKER - SYNTHETIC TEST PACKAGE

This package contains 50 fictional users and no real personnel or compliance data:
- 35 General users
- 15 Privileged users, including 5 with DTA as the Privileged User Type
- Organizations include GOV, LM, Boeing, Northrop, Raytheon, and USAF
- Evidence profiles include Current, Overdue, and Mixed

DIRECTORY SCAN TEST
1. Extract this ZIP.
2. Create the users from Test_User_Roster.csv in a test information system.
3. Map the DirectoryScan folder as the test system's shared folder.
4. Select Sync and manually verify the proposed matches.

MANUAL UPLOAD TEST
Use files under ManualUploadSamples when adding or modifying the sample General,
Privileged, and Privileged/DTA users. Every sample is a structurally valid,
single-page synthetic PDF. The application will validate each selected PDF,
compress it into an individual ZIP, reopen and validate the ZIP, and only then
store it in the mapped system folder.

These PDFs are synthetic filename-and-status fixtures; they are not replicas of
the fillable SAAR and do not contain AcroForm fields. Create users from the CSV
before directory-sync testing. New-user discovery from a SAAR still requires a
completed fillable SAAR with Official Email populated.

Dates use DDMMMYYYY. Files dated in 2026 are Current for this test baseline.
Files dated in 2024 or early 2025 are Overdue as of 25 August 2026.