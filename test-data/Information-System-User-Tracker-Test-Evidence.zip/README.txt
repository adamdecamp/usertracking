INFORMATION SYSTEM USER TRACKER - SYNTHETIC TEST PACKAGE

This package contains 50 fictional users and no real personnel or compliance data:
- 35 General users
- 10 Privileged users with different types
- 5 DTA users
- Organizations include GOV, LM, Boeing, Northrop, Raytheon, and USAF
- Evidence profiles include Current, Overdue, and Mixed

DIRECTORY SCAN TEST
1. Extract this ZIP.
2. Create the users from Test_User_Roster.csv in a test information system.
3. Map the DirectoryScan folder as the test system's shared folder.
4. Select Sync and manually verify the proposed matches.

MANUAL UPLOAD TEST
Use files under ManualUploadSamples when adding or modifying the sample General,
Privileged, and DTA users. The application will compress each selected TXT file
into an individual ZIP in the mapped system folder.

Dates use DDMMMYYYY. Files dated in 2026 are Current for this test baseline.
Files dated in 2024 or early 2025 are Overdue as of 25 August 2026.